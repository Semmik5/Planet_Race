async function loadGames() {
  const grid = document.getElementById('game-grid');
  const count = document.getElementById('game-count');

  try {
    const response = await fetch('games.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('Could not load games.json');
    const data = await response.json();
    const games = Array.isArray(data.games) ? data.games : [];

    count.textContent = `${games.length} game${games.length === 1 ? '' : 's'}`;
    grid.innerHTML = '';

    for (const game of games) {
      const card = document.createElement('a');
      card.className = 'game-card';
      card.href = game.path;

      const art = document.createElement('div');
      art.className = 'card-art';
      art.textContent = game.icon || '🎮';

      const body = document.createElement('div');
      body.className = 'card-body';

      const title = document.createElement('h3');
      title.textContent = game.title || 'Untitled Game';

      const desc = document.createElement('p');
      desc.textContent = game.description || '';

      const meta = document.createElement('div');
      meta.className = 'card-meta';

      for (const tag of (game.tags || [])) {
        const span = document.createElement('span');
        span.className = 'tag';
        span.textContent = tag;
        meta.appendChild(span);
      }

      body.append(title, desc, meta);
      card.append(art, body);
      grid.appendChild(card);
    }

    if (!games.length) {
      grid.textContent = 'No games have been added yet.';
    }
  } catch (err) {
    count.textContent = 'Error';
    grid.innerHTML = `<div class="game-card"><div class="card-body"><h3>Couldn’t load the library</h3><p>${err.message}</p></div></div>`;
  }
}

loadGames();
