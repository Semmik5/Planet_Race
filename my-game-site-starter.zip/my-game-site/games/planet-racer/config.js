// Central upgrade/config file.
// Future balance changes can usually start here.
window.PLANET_RACER_CONFIG = {
  car: {
    maxSpeed: 210,
    acceleration: 95,
    braking: 130,
    steering: 2.5,
    drag: 0.44,
    engineDurability: 1600
  },
  track: {
    roadWidth: 520,
    shoulderWidth: 95
  }
};
