(() => {
  const cfg = window.PLANET_RACER_CONFIG;
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');

  const speedEl = document.getElementById('speed');
  const distanceEl = document.getElementById('distance');
  const healthEl = document.getElementById('engine-health');

  const input = { left:false, right:false, throttle:false, brake:false };
  let speed = 0;
  let x = canvas.width / 2;
  let distance = 0;
  let engineHealth = 100;
  let last = performance.now();
  let roadScroll = 0;

  function bindHold(id, key) {
    const el = document.getElementById(id);
    const on = e => { e.preventDefault(); input[key] = true; el.classList.add('active'); };
    const off = e => { e.preventDefault(); input[key] = false; el.classList.remove('active'); };
    el.addEventListener('pointerdown', on);
    el.addEventListener('pointerup', off);
    el.addEventListener('pointercancel', off);
    el.addEventListener('pointerleave', off);
  }

  bindHold('left','left');
  bindHold('right','right');
  bindHold('throttle','throttle');
  bindHold('brake','brake');

  const keyMap = {
    ArrowLeft:'left', a:'left', A:'left',
    ArrowRight:'right', d:'right', D:'right',
    ArrowUp:'throttle', w:'throttle', W:'throttle',
    ArrowDown:'brake', s:'brake', S:'brake'
  };

  addEventListener('keydown', e => {
    const k = keyMap[e.key];
    if (k) { input[k] = true; e.preventDefault(); }
  }, { passive:false });

  addEventListener('keyup', e => {
    const k = keyMap[e.key];
    if (k) { input[k] = false; e.preventDefault(); }
  }, { passive:false });

  function update(dt) {
    const car = cfg.car;

    if (input.throttle && engineHealth > 0) {
      speed += car.acceleration * dt * Math.max(0.2, 1 - speed / (car.maxSpeed * 1.15));
      engineHealth -= (speed / car.maxSpeed) * 0.22 * dt * (1200 / car.engineDurability);
    } else {
      speed -= car.drag * 28 * dt;
    }

    if (input.brake) speed -= car.braking * dt;

    speed = Math.max(0, Math.min(car.maxSpeed, speed));
    engineHealth = Math.max(0, Math.min(100, engineHealth));

    const steerScale = 0.35 + Math.min(1, speed / 70);
    if (input.left) x -= car.steering * 120 * steerScale * dt;
    if (input.right) x += car.steering * 120 * steerScale * dt;

    const roadLeft = (canvas.width - cfg.track.roadWidth) / 2;
    const roadRight = roadLeft + cfg.track.roadWidth;
    x = Math.max(roadLeft + 26, Math.min(roadRight - 26, x));

    distance += (speed / 3.6) * dt;
    roadScroll = (roadScroll + speed * dt * 1.9) % 80;

    speedEl.textContent = `${Math.round(speed)} km/h`;
    distanceEl.textContent = `${Math.round(distance)} m`;
    healthEl.textContent = `${Math.ceil(engineHealth)}%`;
  }

  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0,0,w,h);

    // grass
    ctx.fillStyle = '#16351f';
    ctx.fillRect(0,0,w,h);

    // shoulders
    const roadLeft = (w - cfg.track.roadWidth) / 2;
    ctx.fillStyle = '#574e45';
    ctx.fillRect(roadLeft - cfg.track.shoulderWidth, 0, cfg.track.roadWidth + cfg.track.shoulderWidth * 2, h);

    // road
    ctx.fillStyle = '#262d36';
    ctx.fillRect(roadLeft, 0, cfg.track.roadWidth, h);

    // edge lines
    ctx.strokeStyle = '#eef2f7';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(roadLeft + 8, 0); ctx.lineTo(roadLeft + 8, h);
    ctx.moveTo(roadLeft + cfg.track.roadWidth - 8, 0); ctx.lineTo(roadLeft + cfg.track.roadWidth - 8, h);
    ctx.stroke();

    // center dashed line
    ctx.strokeStyle = '#e8cf55';
    ctx.lineWidth = 6;
    ctx.setLineDash([34,46]);
    ctx.lineDashOffset = roadScroll;
    ctx.beginPath();
    ctx.moveTo(w/2, -100); ctx.lineTo(w/2, h+100);
    ctx.stroke();
    ctx.setLineDash([]);

    // scenery
    ctx.fillStyle = '#285530';
    for (let y=-80 + (roadScroll*2)%120; y<h+80; y+=120) {
      ctx.beginPath(); ctx.arc(55, y, 25, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(w-55, y+50, 20, 0, Math.PI*2); ctx.fill();
    }

    // car
    const carY = h - 110;
    ctx.save();
    ctx.translate(x, carY);
    ctx.fillStyle = '#d9464b';
    ctx.fillRect(-24,-42,48,84);
    ctx.fillStyle = '#1a2535';
    ctx.fillRect(-18,-25,36,26);
    ctx.fillStyle = '#f3f4f6';
    ctx.fillRect(-20,-38,9,8);
    ctx.fillRect(11,-38,9,8);
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(-29,-28,7,19);
    ctx.fillRect(22,-28,7,19);
    ctx.fillRect(-29,14,7,19);
    ctx.fillRect(22,14,7,19);
    ctx.restore();

    if (engineHealth <= 0) {
      ctx.fillStyle = 'rgba(0,0,0,.58)';
      ctx.fillRect(0,0,w,h);
      ctx.fillStyle = '#fff';
      ctx.textAlign = 'center';
      ctx.font = '700 34px system-ui';
      ctx.fillText('ENGINE FAILED', w/2, h/2);
      ctx.font = '18px system-ui';
      ctx.fillText('Reload the page to restart this prototype.', w/2, h/2+38);
    }
  }

  function loop(now) {
    const dt = Math.min(0.04, (now - last) / 1000);
    last = now;
    update(dt);
    draw();
    requestAnimationFrame(loop);
  }

  requestAnimationFrame(loop);
})();
