# My Game Site

A simple modular game hub designed for GitHub Pages.

## Upload to GitHub

Upload the **contents of this folder** to the root of your repository:

- `index.html`
- `games.json`
- `shared/`
- `games/`

Then enable GitHub Pages:

1. Open your repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select `main` and `/ (root)`.
5. Save.

Your site should appear at:

`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`

## Adding games

Create a new folder:

`games/my-new-game/`

Then add it to `games.json`.

Example:

```json
{
  "id": "my-new-game",
  "title": "My New Game",
  "description": "Description here.",
  "path": "games/my-new-game/",
  "icon": "🎮",
  "tags": ["Arcade"]
}
```

## Planet Racer

The Planet Racer starter is under:

`games/planet-racer/`

Important files:

- `config.js` – balance values such as speed, acceleration and durability.
- `game.js` – gameplay logic.
- `style.css` – game layout and mobile controls.
- `index.html` – game page.

This structure is intentionally modular so future upgrades can be made without rebuilding the whole site.
